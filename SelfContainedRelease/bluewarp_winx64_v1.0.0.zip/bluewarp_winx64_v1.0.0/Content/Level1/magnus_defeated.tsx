<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="magnus_defeated" tilewidth="32" tileheight="32" tilecount="8" columns="4">
 <image source="magnus_defeated_set.png" width="128" height="64"/>
</tileset>
